package lu.ethan;

import junit.framework.TestCase;

/**
 * Created by ludai on 16/11/16.
 */
public class PerformanceTest extends TestCase {
    public void testBytesToMegabytes() throws Exception {

    }

}