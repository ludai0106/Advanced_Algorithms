package lu.ethan;

import junit.framework.TestCase;

/**
 * Created by ludai on 16/11/16.
 */
public class ScheduleTest extends TestCase {
    public void testCompareTo() throws Exception {

    }

    public void testGetMaxT() throws Exception {

    }

    public void testGetDepth() throws Exception {

    }

    public void testGetJobs() throws Exception {

    }

    public void testGetJob() throws Exception {

    }

    public void testGetTotalTime() throws Exception {

    }

    public void testGetTardiness() throws Exception {

    }

    public void testContainsJob() throws Exception {

    }

    public void testGetOpt() throws Exception {

    }

}