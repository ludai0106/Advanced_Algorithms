package lu.ethan;

import junit.framework.TestCase;

/**
 * Created by ludai on 16/11/16.
 */
public class ExactTest extends TestCase {
    public void testMax_process_time() throws Exception {

    }

    public void testSum_process_time() throws Exception {

    }

    public void testFront_largest() throws Exception {

    }

    public void testBack_smallest() throws Exception {

    }

    public void testGetSigma() throws Exception {

    }

    public void testGetSchedule() throws Exception {

    }

}