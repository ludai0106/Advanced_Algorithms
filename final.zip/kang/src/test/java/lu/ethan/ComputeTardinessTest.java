package lu.ethan;

import junit.framework.TestCase;

/**
 * Created by ludai on 16/11/16.
 */
public class ComputeTardinessTest extends TestCase {

    public void testReadInstance() throws Exception {

    }

    public void testMain() throws Exception {

    }

}