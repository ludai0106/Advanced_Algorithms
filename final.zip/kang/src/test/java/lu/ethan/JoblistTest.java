package lu.ethan;

import junit.framework.TestCase;

/**
 * Created by ludai on 16/11/16.
 */
public class JoblistTest extends TestCase {
    public void testShowJobs() throws Exception {

    }

    public void testNumJobs() throws Exception {

    }

    public void testGetIndex() throws Exception {

    }

    public void testGetJoblist() throws Exception {

    }

    public void testGetJobsize() throws Exception {

    }

    public void testHashCode() throws Exception {

    }

    public void testEquals() throws Exception {

    }

}